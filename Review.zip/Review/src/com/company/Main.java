package com.company;
import java.util.*;

public class Main {

    public static void main(String[] args) {
        Init();
    }

    public static class Player{
        Scanner input = new Scanner(System.in);
        String name = input.nextLine();
    }

    public static class Data{
        int value = 3;
    }

    public static void Init(){
        boolean player = true;
        Data pile1 = new Data();
        Data pile2 = new Data();
        Data pile3 = new Data();
        print("What is the name of the first player?: ");
        Player player1 = new Player();
        print("And the second?: ");
        Player player2 = new Player();
        pile2.value = 4;
        pile3.value = 5;
        int[] piles;
        piles = new int[]{pile1.value,pile2.value,pile3.value};
        Display(player1.name, player2.name, piles, player);
    }

    public static void Display(String player1, String player2, int[] piles, boolean player){
        for(int i = 0; i <= 2; i++){
            println("Pile "+ (i + 1) + " : " + piles[i]);
        }
        gamePlay(player1, player2, piles, player);
    }

    public static void gamePlay(String name1,String name2,int[] piles, boolean player){
        Scanner input = new Scanner(System.in);
        int choice = 0;
        do {
            if (arraySum(piles) == 0){
                if (player == true){

                }
                println("Thanks for playing");
            }
            if (player) {
                print("What pile will you choose " + name1 + "?:");
            } else {
                print("What pile will you choose " + name2 + "?:");
            }
                choice = input.nextInt();

            if (choice > 3 | choice < 1) {

                println("That's not an option bud");
            }
        } while (choice > 3 | choice < 1);

        int out = 0;
        do{
            print("How many are we taking out?: ");
            out = input.nextInt();

            if(out > piles[choice - 1]){
                println(("Sorry, that's an invalid choice."));
            }
            else{
                piles[choice - 1] = piles[choice - 1] - out;
                if(player){
                    player = false;
                }
                else{
                    player = true;
                }
                Display(name1, name2,piles, player);
            }
        } while (out > piles[choice - 1]);
    }

    public static void println(Object line){
       System.out.println(line);
    }

    public static void print(Object line){
        System.out.print(line);
    }
}
